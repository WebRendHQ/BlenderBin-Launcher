import sys
import os
import platform
import importlib.util
import subprocess
import tempfile
import traceback
import time
import ctypes
import threading
import json
import requests
from concurrent.futures import ThreadPoolExecutor, Future
from typing import Tuple, Optional, Dict, Set

# GitHub version check constants
GITHUB_OWNER = "WebRendHQ"
GITHUB_REPO = "BlenderBin-Launcher"
GITHUB_VERSION_URL = f"https://raw.githubusercontent.com/{GITHUB_OWNER}/{GITHUB_REPO}/main/version.json"
GITHUB_API_RELEASE_URL = f"https://api.github.com/repos/{GITHUB_OWNER}/{GITHUB_REPO}/releases/recommended"

def get_download_url(version: str) -> str:
    """
    Get the download URL for the BlenderBin.zip file directly from GitHub repository structure.
    """
    # Ensure version starts with 'v'
    if not version.startswith('v'):
        version = 'v' + version
    
    # Construct the raw content URL to the zip file in the repository
    raw_url = f"https://github.com/{GITHUB_OWNER}/{GITHUB_REPO}/raw/main/releases/recommended/{version}/BlenderBin.zip"
    
    # Alternative URL formats if the above doesn't work:
    # raw_url = f"https://raw.githubusercontent.com/{GITHUB_OWNER}/{GITHUB_REPO}/main/releases/recommended/{version}/BlenderBin.zip"
    # Or to download from the blob view:
    # raw_url = f"https://github.com/{GITHUB_OWNER}/{GITHUB_REPO}/blob/main/releases/recommended/{version}/BlenderBin.zip?raw=true"
    
    print(f"Constructed download URL: {raw_url}")
    
    # Optionally verify the URL is valid
    headers = {
        'User-Agent': 'BlenderBin-Updater'
    }
    
    response = requests.head(raw_url, headers=headers, timeout=10)
    if response.status_code != 200:
        # Try alternative URL format
        raw_url = f"https://raw.githubusercontent.com/{GITHUB_OWNER}/{GITHUB_REPO}/main/releases/recommended/{version}/BlenderBin.zip"
        print(f"Trying alternative URL: {raw_url}")
        
        response = requests.head(raw_url, headers=headers, timeout=10)
        if response.status_code != 200:
            raise ValueError(f"Could not find BlenderBin.zip at path 'releases/recommended/{version}/' (Status code: {response.status_code})")
    
    return raw_url

def check_github_version() -> bool:
    """
    Check GitHub for newer version and update if needed.
    Returns True if update was performed, False otherwise.
    """
    try:
        import bpy
        import zipfile
        import shutil
        
        # Get Blender's addons directory path
        addons_path = bpy.utils.user_resource('SCRIPTS', path="addons")
        
        # The target BlenderBin addon folder path
        addon_folder_path = os.path.join(addons_path, "BlenderBin")
        
        # The target temporary zip path
        scripts_path = os.path.dirname(addons_path)
        temp_zip_path = os.path.join(scripts_path, "BlenderBin_temp.zip")
        
        print(f"Addons directory: {addons_path}")
        print(f"Target addon folder path: {addon_folder_path}")
        print(f"Temporary download path: {temp_zip_path}")

        # Get remote version info
        headers = {
            'Accept': 'application/vnd.github.v3.raw',
            'User-Agent': 'BlenderBin-Updater'
        }
        response = requests.get(GITHUB_VERSION_URL, headers=headers, timeout=10)
        response.raise_for_status()
        version_data = response.json()
        
        remote_version = version_data.get("version")
        
        if not remote_version:
            print("Invalid version data from GitHub")
            return False
            
        # Compare versions
        local_version = ".".join(map(str, bl_info["version"]))
        if remote_version == local_version:
            print(f"Already at latest version {local_version}")
            return False
            
        print(f"New version available: {remote_version} (current: {local_version})")
        
        # Get download URL from GitHub API
        try:
            zip_url = get_download_url(remote_version)
            print(f"Downloading from: {zip_url}")
        except Exception as e:
            print(f"Error getting download URL: {e}")
            return False
        
        # Download new zip with proper headers
        headers = {
            'Accept': 'application/octet-stream',
            'User-Agent': 'BlenderBin-Updater'
        }
        zip_response = requests.get(zip_url, headers=headers, timeout=30)
        zip_response.raise_for_status()
        
        # Create backup of existing addon folder
        backup_folder_path = addon_folder_path + "_backup"
        if os.path.exists(addon_folder_path):
            # Remove old backup if it exists
            if os.path.exists(backup_folder_path):
                shutil.rmtree(backup_folder_path, ignore_errors=True)
            
            # Create new backup
            try:
                shutil.copytree(addon_folder_path, backup_folder_path)
                print(f"Created backup of addon folder at {backup_folder_path}")
            except Exception as e:
                print(f"Warning: Could not create backup: {e}")
                
        # Save the downloaded zip to temporary location
        try:
            with open(temp_zip_path, "wb") as f:
                f.write(zip_response.content)
            
            # Extract the zip contents
            with zipfile.ZipFile(temp_zip_path, 'r') as zip_ref:
                # Get a list of all entries in the zip
                entries = zip_ref.namelist()
                print(f"ZIP contains entries: {entries}")
                
                # Check if there's a BlenderBin folder within the zip
                blenderbin_entries = [e for e in entries if e.startswith("BlenderBin/")]
                
                if blenderbin_entries:
                    # The zip has a BlenderBin folder, extract it to the addons directory
                    print("Extracting BlenderBin folder from zip")
                    
                    # Remove existing addon folder if it exists
                    if os.path.exists(addon_folder_path):
                        shutil.rmtree(addon_folder_path, ignore_errors=True)
                    
                    # Extract only the BlenderBin folder
                    for entry in blenderbin_entries:
                        zip_ref.extract(entry, addons_path)
                    
                else:
                    # The zip doesn't have a BlenderBin folder, assume the contents should
                    # be placed directly in the BlenderBin folder
                    print("No BlenderBin folder found in zip, creating folder structure")
                    
                    # Remove existing addon folder if it exists
                    if os.path.exists(addon_folder_path):
                        shutil.rmtree(addon_folder_path, ignore_errors=True)
                    
                    # Create addon folder
                    os.makedirs(addon_folder_path, exist_ok=True)
                    
                    # Extract everything to the addon folder
                    for entry in entries:
                        output_path = os.path.join(addon_folder_path, entry)
                        # Create directory if needed
                        if not os.path.exists(os.path.dirname(output_path)):
                            os.makedirs(os.path.dirname(output_path), exist_ok=True)
                        
                        # Extract file
                        with zip_ref.open(entry) as source, open(output_path, "wb") as target:
                            shutil.copyfileobj(source, target)
            
            print(f"Successfully extracted BlenderBin to {addon_folder_path}")
            
            # Remove the temporary zip file
            if os.path.exists(temp_zip_path):
                os.remove(temp_zip_path)
            
            # Tell the user they need to restart Blender
            import bpy
            def show_restart_message():
                def draw(self, context):
                    self.layout.label(text=f"BlenderBin updated to version {remote_version}")
                    self.layout.label(text="Please restart Blender to use the new version")
                
                bpy.context.window_manager.popup_menu(draw, title="BlenderBin Updated", icon="INFO")
            
            # Schedule the popup to be shown after the current operation completes
            bpy.app.timers.register(show_restart_message, first_interval=0.1)
                
            return True
        
        except Exception as e:
            # Restore backup if extraction failed
            if os.path.exists(backup_folder_path):
                if os.path.exists(addon_folder_path):
                    shutil.rmtree(addon_folder_path, ignore_errors=True)
                shutil.copytree(backup_folder_path, addon_folder_path)
                print(f"Restored addon folder from backup")
            
            print(f"Error extracting zip: {e}")
            traceback.print_exc()
            return False
        
        finally:
            # Clean up backup folder
            if os.path.exists(backup_folder_path):
                shutil.rmtree(backup_folder_path, ignore_errors=True)
            
            # Clean up temporary zip
            if os.path.exists(temp_zip_path):
                try:
                    os.remove(temp_zip_path)
                except:
                    pass
                
    except Exception as e:
        print(f"Error checking for updates: {str(e)}")
        traceback.print_exc()
        return False
    

bl_info = {
    "name": "BlenderBin v1.0.2",
    "description": "Blender plugins from blenderbin.com",
    "blender": (2, 80, 0),
    "category": "3D View",
    "version": (1, 0, 2),
    "author": "blenderbin.com",
    "location": "View3D > Sidebar > BlenderBin",
    "warning": "",
    "wiki_url": "https://blenderbin.com",
    "tracker_url": "",
    "support": "COMMUNITY",
}

# Global variables
_thread_pool = ThreadPoolExecutor(max_workers=3)
_loading_future: Optional[Future] = None
_blenderbin_module = None
is_registered = False
LOCAL_VERSION = ".".join(map(str, bl_info["version"]))

# AWS credentials
AWS_ACCESS_KEY = "AKIAZI2LISZN3U64UQ6O"
AWS_SECRET_KEY = "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"
AWS_REGION = "us-east-2"
LAMBDA_URL = f"https://3nsyezgtdyhs6igigkizubgfgq0kthdm.lambda-url.{AWS_REGION}.on.aws"

# Private key for signing
PRIVATE_KEY = """-----BEGIN PRIVATE KEY-----
MIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQCl4N0yEd5GI03Y
iy9XpgBh7LrZKWjoFP1kpDRhiDcZcTDFGw/z+DUwHnb5S4uba/pFACVpmWDK+ptE
5Q5POu3612xyl3atdAd+AnVoI8ZaiaoQzvvA/uoO072uACv/xb4LhQZKLC6mFs6U
tkyTpnQgl96AQxYHv0J8jI/jXX9rMst4/irBvnl9VL+AdQz65oVVQVhhG3k+kHrE
mc+aSA8SH7G+H3Pbkx4OJkylDJJQHIVWAaepUjmwm0lATQzj5DzJNrRPZDEcyByR
SWGyiiA2yDA9mxb0jEsNLy4nFewe/JLX9Cb4dJ6ViGRChebzlcQX7Vxh99bW0NDn
HnonF4WTAgMBAAECggEALoqNBYNl7h/xs5Q50EnPSap2MoAf4x4giqBX4hWqAAV2
PZd+PmGh6sJhd0ju/sipC7sixCI4ujreXdI21ZwfMYZH8070CW7Iu15NOs7u1HBT
uyuYD2p2mXpnee6qabU9wVWtkhobbJZxl+AeVD8bzhlOYIZyI/JR4Ug/BvgwzA6c
yJDJxRN/dMeraxsku10xFxSzS6WmdzhUyGEouFDsJfY76/a2S3mnLY0gvqsoiepC
zFbAYGJ6K7YOzGHh/AkB0CgotcTfIRyxqlg+aCsZSDEDEjLoGYILbj5aYRRQo9xf
Gg3VrsFcGC6O/m7PeNVkam2f7BGMMhZmWyPi1lNroQKBgQDRvylysgBZSfB9N67J
UoZXeh86No7+towNdlClhxeF648oeB0e3cCO/gm/X4AKZRYFOEr6CkyLh54bohX3
oz+HVWOL8K5640PMYpIZlMcJ4XN2/I8GdATaH3XujlItMN/FgvcnS23zN5yeaqdM
YHsTv4Za9f24x/vIl1oUGZdzjwKBgQDKdTNpoErX24cBetvDJkK2rcclO9rNjP2F
hTkqnH6aw4Rs8/+9J3psNohG8KAWsDwsmlKm1taIQu/HLERcD8NPzgNCrwvZcqfc
B5iWPdFSw+V34wR1daPURdqKnfY7OXHoleh0Dn6G7NYfGRyAvXieMYDeM/1X+qME
nV2gN2b7vQKBgQCHTFuNO9tTvYlfDKM4BH7aQNGR+I2nKtQO/woorIr0/S18ena2
aW8EDkT1aMIscmaQ+W4L+sbDnrjTtGudMXYSc3diVuAGL0GVvuPlkn4OFpsn3uTX
0dErbu3g83d45TUDsGaDt3l2UaI64iuG7hmWdI5TcKi5IG9/Rnp5ysRSawKBgARs
eysbrYb57QFDRfoFo/+J3IgbvrQvGHsKZi1gLgQDsakPy86+RhaHOoMSTu0v/KCc
3qF2oElp7QNVHElGruXXgoq6eG/P6YsNP3BI+YHtdd4gv8AxSdshi5zrxq2Um8CR
RfsDNhCMrEERs2W8vh32xvIUAL0jZNx888bEbyOhAoGAbAonzqUnusmRFKuyh1w0
qjWhjP8vxg1BAuknQTEQb7Kkeob3DvnfhvwIJVC3bzbk5b509KOv+fOf4U4kxKzc
9ml29LUEOOjsor0mjNOAd2g2ZVS3fs7a+1ir80M7ss10YVbZZqF/lDI/ZRMakMG3
rtZLiQPFjAqEYDjw/rNQAMY=
-----END PRIVATE KEY-----"""

# Dependencies to install
DEPENDENCIES = [
    "requests",
    "cryptography",
]

# Global variables for dependency management
_installed_deps: Set[str] = set()
_deps_lock = threading.Lock()
_deps_temp_dir = None

def _install_dependency(dep: str, temp_dir: str, python_exe: str) -> bool:
    """
    Install a single dependency using pip.
    Returns True if successful, False otherwise.
    """
    try:
        # Skip if already installed in this session
        with _deps_lock:
            if dep in _installed_deps:
                print(f"Dependency {dep} was already installed in this session")
                return True

        # Try importing first
        try:
            importlib.import_module(dep)
            with _deps_lock:
                _installed_deps.add(dep)
            print(f"Dependency {dep} is already installed in Python environment")
            return True
        except ImportError:
            pass

        print(f"Installing dependency: {dep}")
        subprocess.check_call([
            python_exe, "-m", "pip", "install",
            "--target", temp_dir,
            dep
        ])
        
        # Verify installation
        sys.path.insert(0, temp_dir)
        importlib.import_module(dep)
        
        with _deps_lock:
            _installed_deps.add(dep)
        
        print(f"Successfully installed {dep}")
        return True
        
    except Exception as e:
        print(f"Failed to install {dep}: {e}")
        return False

def ensure_dependencies_installed() -> bool:
    """
    Ensure all required dependencies are installed in Blender's Python environment
    Returns True if all dependencies are available (or were successfully installed)
    """
    global _deps_temp_dir
    
    print("Checking for required dependencies...")
    try:
        # Get Blender's Python executable path
        python_exe = sys.executable
        
        # Create a temporary directory for pip operations if not exists
        if _deps_temp_dir is None:
            _deps_temp_dir = tempfile.mkdtemp(prefix="blenderbin_deps_")
            
        # Add temp dir to Python path if not already there
        if _deps_temp_dir not in sys.path:
            sys.path.insert(0, _deps_temp_dir)
            
        # Install dependencies in parallel
        with ThreadPoolExecutor(max_workers=len(DEPENDENCIES)) as executor:
            futures = {
                executor.submit(_install_dependency, dep, _deps_temp_dir, python_exe): dep 
                for dep in DEPENDENCIES
            }
            
            # Wait for all installations to complete
            failed_deps = []
            for future in futures:
                dep = futures[future]
                try:
                    if not future.result():
                        failed_deps.append(dep)
                except Exception as e:
                    print(f"Error installing {dep}: {e}")
                    failed_deps.append(dep)
            
            if failed_deps:
                print(f"Failed to install dependencies: {', '.join(failed_deps)}")
                return False
                
            print("All dependencies were successfully installed/verified")
            return True
            
    except Exception as e:
        print(f"Error installing dependencies: {e}")
        traceback.print_exc()
        return False

def sign_content(content: str) -> str:
    """
    Sign content using RSA private key
    """
    try:
        # Import here to ensure the modules are available
        import base64
        from cryptography.hazmat.primitives import serialization, hashes
        from cryptography.hazmat.primitives.asymmetric import padding
        from cryptography.hazmat.backends import default_backend
        
        # Load private key
        private_key = serialization.load_pem_private_key(
            PRIVATE_KEY.encode(),
            password=None,
            backend=default_backend()
        )
        
        # Sign content
        signature = private_key.sign(
            content.encode(),
            padding.PSS(
                mgf=padding.MGF1(hashes.SHA256()),
                salt_length=padding.PSS.MAX_LENGTH
            ),
            hashes.SHA256()
        )
        
        return base64.b64encode(signature).decode('utf-8')
    except Exception as e:
        print(f"Failed to sign content: {e}")
        traceback.print_exc()
        return ""

def get_challenge(max_retries=3, retry_delay=1) -> Tuple[str, str]:
    """
    Request a new challenge from the Lambda function with retries
    Returns a tuple of (challenge, session_id)
    """
    # Import here to ensure modules are available
    import requests
    import json
    
    headers = {
        'X-Amz-Security-Token': None,
        'Authorization': f'AWS4-HMAC-SHA256 Credential={AWS_ACCESS_KEY}/{AWS_REGION}/lambda/aws4_request',
        'Content-Type': 'application/json'
    }
    
    payload = {
        "request_type": "challenge",
        "os_type": platform.system().lower(),
        "python_version": f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}"
    }

    print(f"Requesting challenge from {LAMBDA_URL}")
    print(f"Request payload: {payload}")
    
    last_error = None
    for attempt in range(max_retries):
        try:
            response = requests.post(LAMBDA_URL, json=payload, headers=headers, timeout=10)
            
            print(f"Challenge response status: {response.status_code}")
            print(f"Challenge response content: {response.text[:200]}...")  # Print start of response
            
            if response.status_code == 200:
                data = response.json()
                return data["challenge"], data["session_id"]
            
            if 500 <= response.status_code < 600:
                print(f"Server error (attempt {attempt+1}/{max_retries}), retrying in {retry_delay}s")
                time.sleep(retry_delay)
                continue
                
            print(f"Request failed with status {response.status_code}: {response.text}")
            response.raise_for_status()
            
        except Exception as e:
            last_error = e
            print(f"Exception during challenge request (attempt {attempt+1}/{max_retries}): {type(e).__name__}: {str(e)}")
            if attempt < max_retries - 1:
                print(f"Retrying in {retry_delay}s...")
                time.sleep(retry_delay)
            continue
            
    raise RuntimeError(f"Failed to get challenge after {max_retries} attempts: {last_error}")

def solve_challenge(challenge: str, init_content: str) -> str:
    """
    Generate challenge solution
    """
    import hashlib
    return hashlib.sha256(f"{challenge}{init_content}".encode()).hexdigest()

def aes_decrypt_cbc(ciphertext: bytes, key: bytes, iv: bytes) -> bytes:
    """
    AES-256 CBC decryption with PKCS7 unpadding
    """
    # Import here to ensure modules are available
    from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
    from cryptography.hazmat.primitives.padding import PKCS7
    from cryptography.hazmat.backends import default_backend
    
    cipher = Cipher(algorithms.AES(key), modes.CBC(iv), backend=default_backend())
    decryptor = cipher.decryptor()
    padded_data = decryptor.update(ciphertext) + decryptor.finalize()
    
    unpadder = PKCS7(128).unpadder()
    data = unpadder.update(padded_data) + unpadder.finalize()
    return data

def verify_hmac(ciphertext: bytes, hmac_key: bytes, received_hmac: bytes) -> bool:
    """
    Verify HMAC of the ciphertext
    """
    import hmac
    import hashlib
    calculated_hmac = hmac.new(hmac_key, ciphertext, hashlib.sha256).digest()
    return hmac.compare_digest(calculated_hmac, received_hmac)

def get_blenderbin_code(max_retries=3, retry_delay=1) -> str:
    """
    Download and verify the Python code from Lambda function with retries
    """
    # Import here to ensure modules are available
    import requests
    import json
    import base64
    import hashlib
    
    # Get the actual filename of this file
    current_filename = os.path.basename(__file__)
    
    # Read the current file content exactly as it is on disk
    with open(__file__, 'rb') as f:
        init_content_bytes = f.read()
    
    # Convert to string with UTF-8 encoding, preserving exact content
    init_content = init_content_bytes.decode('utf-8', errors='replace')
    
    print(f"File content length: {len(init_content)} bytes")
    print(f"Filename being sent: {current_filename}")
    
    last_error = None
    for attempt in range(max_retries):
        try:
            # Get challenge
            challenge, session_id = get_challenge()
            
            print(f"Got challenge: {challenge[:10]}... and session_id: {session_id[:10]}...")
            
            # Solve challenge
            solution = solve_challenge(challenge, init_content)
            print(f"Generated solution: {solution[:10]}...")
            
            # Sign the init content
            signature = sign_content(init_content)
            print(f"Generated signature: {signature[:10]}...")
            
            # Request verification and code
            headers = {
                'X-Amz-Security-Token': None,
                'Authorization': f'AWS4-HMAC-SHA256 Credential={AWS_ACCESS_KEY}/{AWS_REGION}/lambda/aws4_request',
                'Content-Type': 'application/json'
            }
            
            payload = {
                "request_type": "verify",
                "os_type": platform.system().lower(),
                "python_version": f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}",
                "init_content": base64.b64encode(init_content.encode()).decode(),
                "solution": solution,
                "session_id": session_id,
                "signature": signature,
                "filename": current_filename
            }
            
            print(f"Sending verification request to {LAMBDA_URL}")
            print(f"Payload keys: {list(payload.keys())}")
            print(f"init_content length: {len(payload['init_content'])} bytes")
            
            response = requests.post(LAMBDA_URL, json=payload, headers=headers, timeout=15)
            
            print(f"Verification response status: {response.status_code}")
            
            if response.status_code == 200:
                print("Successfully received encrypted code")
                data = response.json()
                
                # Decode and verify
                encrypted_code = base64.b64decode(data["encrypted_file"])
                aes_key = base64.b64decode(data["aes_key"])
                iv = base64.b64decode(data["iv"])
                received_hmac = base64.b64decode(data["hmac"])
                hmac_key = base64.b64decode(data["hmac_key"])
                
                print(f"Received encrypted code: {len(encrypted_code)} bytes")
                print(f"Verifying HMAC...")
                
                if not verify_hmac(encrypted_code, hmac_key, received_hmac):
                    raise RuntimeError("HMAC verification failed")
                
                print("HMAC verification successful, decrypting code...")
                decrypted_code = aes_decrypt_cbc(encrypted_code, aes_key, iv)
                print(f"Successfully decrypted code: {len(decrypted_code)} bytes")
                
                return decrypted_code.decode('utf-8')
            
            if 500 <= response.status_code < 600:
                print(f"Server error (attempt {attempt+1}/{max_retries}), retrying in {retry_delay}s")
                time.sleep(retry_delay)
                continue
            
            print(f"Request failed with status {response.status_code}: {response.text}")
            response.raise_for_status()
            
        except Exception as e:
            last_error = e
            print(f"Exception during verification (attempt {attempt+1}/{max_retries}): {type(e).__name__}: {str(e)}")
            traceback.print_exc()
            if attempt < max_retries - 1:
                print(f"Retrying in {retry_delay}s...")
                time.sleep(retry_delay)
            continue
            
    raise ImportError(f"Failed to load blenderbin code after {max_retries} attempts: {str(last_error)}")

def _setup_memory_protections():
    """
    Set up various memory and debugging protections
    """
    system = platform.system().lower()
    
    if system == "windows":
        try:
            # Prevent debugger attachment
            kernel32 = ctypes.windll.kernel32
            kernel32.SetProcessDEPPolicy(0x00000001)  # Enable DEP
            
            # Make the process "critical"
            kernel32.SetProcessShutdownParameters(0x4FF, 0)
            
            # Detect and prevent memory dumping
            def prevent_dump():
                while True:
                    if kernel32.IsDebuggerPresent():
                        os._exit(1)
                    time.sleep(0.1)
            
            threading.Thread(target=prevent_dump, daemon=True).start()
            
        except Exception:
            pass
            
    elif system == "linux":
        try:
            import resource
            import signal
            
            # Prevent ptrace attachment
            def _disable_ptrace():
                libc = ctypes.CDLL('libc.so.6')
                PR_SET_DUMPABLE = 4
                PR_SET_TRACEABLE = 0x00000001
                libc.prctl(PR_SET_DUMPABLE, 0)
                libc.prctl(PR_SET_TRACEABLE, 0)
            
            _disable_ptrace()
            
            # Set resource limits
            resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
            
            # Handle SIGTRAP
            def _handle_sigtrap(signum, frame):
                os._exit(1)
            
            signal.signal(signal.SIGTRAP, _handle_sigtrap)
            
        except Exception:
            pass
            
    elif system == "darwin":
        try:
            import signal
            
            # Prevent debugging on macOS
            def _handle_siginfo(signum, frame):
                os._exit(1)
                
            signal.signal(signal.SIGINFO, _handle_siginfo)
            
        except Exception:
            pass

def execute_blenderbin_code():
    """
    Execute the downloaded Python code in Blender's memory with protections
    """
    try:
        # Set up memory protections first
        _setup_memory_protections()
        
        # Get the code from Lambda
        code = get_blenderbin_code()
        
        # Create module namespace with required attributes
        module_namespace = {
            '__file__': '<embedded>/blenderbin3119.py',
            '__name__': 'blenderbin3119',
            '__path__': [],
            '__package__': 'blenderbin3119',
            '__builtins__': dict(__builtins__),  # Copy builtins
            '__doc__': None,
            'register': None,
            'unregister': None,
            'bl_info': None,
        }
        
        # Import commonly needed modules into namespace
        import bpy  # Import here to avoid errors in non-Blender environments
        module_namespace.update({
            'sys': sys,
            'os': os,
            'platform': platform,
            'bpy': bpy,
        })
        
        # Execute in protected environment
        exec(code, module_namespace)
        
        # Wrap the module to prevent inspection
        class ProtectedModule:
            def __init__(self, namespace):
                self._namespace = namespace
                self.__file__ = namespace.get('__file__')
                self.__name__ = namespace.get('__name__')
                self.__path__ = namespace.get('__path__')
                self.__package__ = namespace.get('__package__')
                self.bl_info = namespace.get('bl_info')
                
            def __getattr__(self, name):
                if name.startswith('__'):
                    raise AttributeError(f"Protected attribute '{name}' not accessible")
                return self._namespace.get(name)
                
            def register(self):
                reg = self._namespace.get('register')
                if reg and callable(reg):
                    return reg()
                    
            def unregister(self):
                unreg = self._namespace.get('unregister')
                if unreg and callable(unreg):
                    return unreg()
        
        module = ProtectedModule(module_namespace)
        
        # Add to sys.modules
        sys.modules['blenderbin3119'] = module
        
        return module
            
    except Exception as e:
        print(f"Error during execution: {str(e)}")
        traceback.print_exc()
        raise ImportError(f"Failed to execute blenderbin code: {str(e)}")

def register():
    global is_registered, _blenderbin_module, _loading_future
    if not is_registered:
        print("BlenderBin: Starting registration...")
        
        # Check for updates first
        if check_github_version():
            print("BlenderBin: Update downloaded, please restart Blender to use the new version")
            return
        
        # Ensure dependencies are installed first
        if not ensure_dependencies_installed():
            raise ImportError("Failed to install required dependencies")
            
        # Start loading in background
        _loading_future = _thread_pool.submit(execute_blenderbin_code)
        
        # Add callback for when loading completes
        def _on_load_complete(future):
            global _blenderbin_module
            try:
                _blenderbin_module = future.result()
                if hasattr(_blenderbin_module, "register"):
                    _blenderbin_module.register()
                    print("BlenderBin: Successfully registered addon module")
            except Exception as e:
                print(f"Failed to load BlenderBin module: {str(e)}")
                traceback.print_exc()
        
        _loading_future.add_done_callback(_on_load_complete)
        is_registered = True
        print("BlenderBin: Registration process started")

def unregister():
    global is_registered, _blenderbin_module, _loading_future, _thread_pool
    if is_registered:
        print("BlenderBin: Unregistering...")
        
        # Cancel any pending loading operation
        if _loading_future and not _loading_future.done():
            _loading_future.cancel()
        
        if _blenderbin_module is not None and hasattr(_blenderbin_module, "unregister"):
            try:
                _blenderbin_module.unregister()
                print("BlenderBin: Successfully unregistered addon module")
            except Exception as e:
                print(f"Error during unregister: {str(e)}")
        
        _blenderbin_module = None
        is_registered = False
        
        # Shutdown thread pool
        _thread_pool.shutdown(wait=False)
        print("BlenderBin: Unregistration complete")

# Register cleanup handler
import atexit
atexit.register(unregister)

# Only auto-register when run directly, not when imported
if __name__ == "__main__":
    register()