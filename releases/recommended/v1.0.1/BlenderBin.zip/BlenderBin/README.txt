#  ______     __         ______     __   __     _____     ______     ______     ______     __     __   __   
# /\  == \   /\ \       /\  ___\   /\ "-.\ \   /\  __-.  /\  ___\   /\  == \   /\  == \   /\ \   /\ "-.\ \  
# \ \  __<   \ \ \____  \ \  __\   \ \ \-.  \  \ \ \/\ \ \ \  __\   \ \  __<   \ \  __<   \ \ \  \ \ \-.  \ 
#  \ \_____\  \ \_____\  \ \_____\  \ \_\\"\_\  \ \____-  \ \_____\  \ \_\ \_\  \ \_____\  \ \_\  \ \_\\"\_\
#   \/_____/   \/_____/   \/_____/   \/_/ \/_/   \/____/   \/_____/   \/_/ /_/   \/_____/   \/_/   \/_/ \/_/
# 
# ================================================================================
#                        BLENDERBIN EXTENDED LICENSE AGREEMENT
# ================================================================================
# Effective Date: 08/20/2024                        Version: 1.0
#
# This Extended License Agreement ("Agreement") is a legally binding contract
# between BlenderBin LLC ("Licensor"), a company headquartered in New Jersey, USA,
# and the Licensee ("you" or "your"). The Software, including all associated plugins,
# components, and documentation (collectively, the "Software"), is the exclusive property
# of BlenderBin LLC. The Software was developed and designed by WebRend. BlenderBin LLC
# is led by its CEO, Marvens Destine (also known as marv.os), and its CTO, Kevin Vera.
#
# ------------------------------------------------------------------------------
# 1. DEFINITIONS
# ------------------------------------------------------------------------------
# 1.1 "Software" refers to the Blender add-on and all associated components, plugins,
#     and documentation provided by BlenderBin LLC.
# 1.2 "Licensee" means the individual or legal entity that has obtained a copy of the Software.
# 1.3 "Third Party Libraries" denotes external libraries and software components integrated
#     into the Software (including, without limitation, requests, websocket, Google's QUIC,
#     Firebase, Firestore, AES Cryptography, setuptools, Rust, maturin, Zope, gevent, dotenv,
#     Certiffi, CFFI, greenlets, boto3, AWS CLI, James Path, idna, dateutil, charset, PyC parser,
#     etc.), each governed by its own license.
# 1.4 "Non-Personal Data" comprises aggregated usage statistics, system logs, performance metrics,
#     and other technical data collected by the Software that does not include any personally
#     identifiable information.
#
# ------------------------------------------------------------------------------
# 2. GRANT OF LICENSE
# ------------------------------------------------------------------------------
# 2.1 Subject to the terms herein, BlenderBin LLC grants you a non-exclusive, non-transferable,
#     revocable license to install and use the Software solely for your internal business or
#     personal purposes.
# 2.2 This license does not grant you the rights to sublicense, rent, lease, distribute, or otherwise
#     transfer the Software to any third party.
#
# ------------------------------------------------------------------------------
# 3. SCOPE OF USE & RESTRICTIONS
# ------------------------------------------------------------------------------
# 3.1 The Software is provided solely for the use of the Licensee and must not be modified,
#     altered, or adapted in any manner.
# 3.2 UNDER NO CIRCUMSTANCES MAY THE SOFTWARE BE:
#     a. Modified, tampered with, reverse engineered, decompiled, disassembled, or otherwise altered.
#     b. Ripped, plagiarized, copied, or otherwise reproduced or distributed—either in whole or in part—
#        without the express written consent of BlenderBin LLC.
#     c. Utilized to facilitate or engage in any illegal activities or any activities in violation of local,
#        state, or federal laws, including but not limited to the Copyright Act of 1976, the Digital
#        Millennium Copyright Act (DMCA), and the Computer Fraud and Abuse Act (CFAA).
#     d. Combined with any other software or service to produce a derivative work or modified version.
# 3.3 Any attempt to circumvent, disable, or interfere with the protective technological measures
#     implemented to safeguard the Software is strictly prohibited and may result in legal action.
#
# ------------------------------------------------------------------------------
# 4. THIRD PARTY LIBRARIES
# ------------------------------------------------------------------------------
# 4.1 The Software incorporates Third Party Libraries that are governed by separate license
#     agreements. Use of these components is subject to the terms and conditions of their respective
#     licenses.
# 4.2 In the event of any conflict between this Agreement and the terms of a Third Party Library license,
#     the latter shall prevail with respect to that component.
# 4.3 The Licensee agrees to abide by all applicable third-party license terms in connection with the Software.
#
# ------------------------------------------------------------------------------
# 5. INTELLECTUAL PROPERTY RIGHTS
# ------------------------------------------------------------------------------
# 5.1 All title, ownership, and intellectual property rights in and to the Software—including any updates,
#     enhancements, or modifications—are and shall remain the exclusive property of BlenderBin LLC.
# 5.2 The Software is protected by United States copyright law, including the Copyright Act of 1976,
#     and by international treaties.
# 5.3 Except as expressly provided herein, no rights, title, or interest in the Software is transferred to you.
#
# ------------------------------------------------------------------------------
# 6. DATA COLLECTION AND USAGE
# ------------------------------------------------------------------------------
# 6.1 To enhance functionality and support ongoing development, BlenderBin LLC may collect Non-Personal
#     Data regarding the usage, performance, and operation of the Software.
# 6.2 Non-Personal Data may include aggregated statistics, system logs, and performance metrics.
# 6.3 BlenderBin LLC assures that no personal or individually identifiable information is collected.
# 6.4 By using the Software, you consent to the collection and analysis of Non-Personal Data for the purpose
#     of software improvement, performance monitoring, and enhancement of the overall functionality and
#     popularity of BlenderBin plugins.
#
# ------------------------------------------------------------------------------
# 7. TERM AND TERMINATION
# ------------------------------------------------------------------------------
# 7.1 This Agreement is effective as of the Effective Date and shall remain in effect until terminated by
#     either party.
# 7.2 BlenderBin LLC reserves the right to terminate this Agreement immediately, at its sole discretion,
#     if you fail to comply with any provision herein.
# 7.3 Upon termination, you must immediately cease all use of the Software and destroy all copies,
#     whether in whole or in part.
#
# ------------------------------------------------------------------------------
# 8. INDEMNIFICATION
# ------------------------------------------------------------------------------
# 8.1 You agree to indemnify, defend, and hold harmless BlenderBin LLC, its officers, directors, employees,
#     agents, and affiliates from and against any claims, damages, liabilities, costs, or expenses (including
#     reasonable attorneys' fees) arising from your use of the Software or any breach of this Agreement,
#     including claims arising from theft, unauthorized access, or damage.
#
# ------------------------------------------------------------------------------
# 9. DISCLAIMER OF WARRANTIES
# ------------------------------------------------------------------------------
# 9.1 THE SOFTWARE IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, WHETHER EXPRESS OR IMPLIED,
#     INCLUDING WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT.
# 9.2 BLENDERBIN LLC DOES NOT WARRANT THAT THE SOFTWARE WILL MEET YOUR REQUIREMENTS OR BE UNINTERRUPTED,
#     SECURE, TIMELY, OR ERROR-FREE.
#
# ------------------------------------------------------------------------------
# 10. LIMITATION OF LIABILITY
# ------------------------------------------------------------------------------
# 10.1 UNDER NO CIRCUMSTANCES SHALL BLENDERBIN LLC BE LIABLE FOR ANY INDIRECT, INCIDENTAL,
#      CONSEQUENTIAL, SPECIAL, OR EXEMPLARY DAMAGES, OR ANY DAMAGES WHATSOEVER ARISING IN CONNECTION
#      WITH THE USE OR PERFORMANCE OF THE SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
# 10.2 THE TOTAL LIABILITY OF BLENDERBIN LLC FOR ANY CLAIMS ARISING OUT OF THIS AGREEMENT SHALL NOT EXCEED
#      THE AMOUNT PAID BY YOU (IF ANY) FOR THE SOFTWARE.
#
# ------------------------------------------------------------------------------
# 11. GOVERNING LAW & JURISDICTION
# ------------------------------------------------------------------------------
# 11.1 This Agreement shall be governed by and construed in accordance with the laws of the State of
#      New Jersey, USA, and applicable federal laws, including but not limited to the Copyright Act of 1976,
#      the Digital Millennium Copyright Act (DMCA), and the Computer Fraud and Abuse Act (CFAA).
# 11.2 Any disputes arising out of or relating to this Agreement shall be subject to the exclusive jurisdiction
#      of the state and federal courts located in New Jersey, USA.
#
# ------------------------------------------------------------------------------
# 12. AMENDMENTS & MODIFICATIONS
# ------------------------------------------------------------------------------
# 12.1 BlenderBin LLC reserves the right to modify, update, or amend this Agreement at its sole discretion.
# 12.2 Any such modifications will be communicated via official channels and become effective immediately
#      upon notice.
# 12.3 Your continued use of the Software following such modifications constitutes acceptance of the updated terms.
#
# ------------------------------------------------------------------------------
# 13. SEVERABILITY
# ------------------------------------------------------------------------------
# 13.1 If any provision of this Agreement is found to be invalid or unenforceable, that provision shall be
#      severed, and the remaining provisions shall continue in full force and effect.
#
# ------------------------------------------------------------------------------
# 14. ENTIRE AGREEMENT
# ------------------------------------------------------------------------------
# 14.1 This Agreement constitutes the entire agreement between you and BlenderBin LLC with respect to the
#      Software, superseding all prior or contemporaneous agreements, representations, or understandings,
#      whether oral or written.
# 14.2 No waiver of any term or condition of this Agreement shall be deemed a continuing waiver.
#
# ------------------------------------------------------------------------------
# 15. THEFT, DAMAGE, AND SECURITY BREACHES
# ------------------------------------------------------------------------------
# 15.1 The Licensee acknowledges that BlenderBin LLC provides the Software "as is" and does not warrant
#      immunity from theft, unauthorized access, or damage.
# 15.2 BlenderBin LLC shall not be liable for any theft, loss, or damage to the Software, any related
#      data, or the systems on which the Software is installed, regardless of cause—including negligence,
#      security breaches, natural disasters, or other events beyond its control.
# 15.3 The Licensee is responsible for implementing and maintaining appropriate security measures to safeguard
#      their systems and devices on which the Software is installed.
# 15.4 In the event of any theft, loss, or damage, the Licensee shall promptly notify BlenderBin LLC;
#      such notification does not constitute an admission of liability nor provide grounds for any claim.
# 15.5 The Licensee agrees to indemnify, defend, and hold harmless BlenderBin LLC from any and all claims,
#      losses, or damages (including reasonable attorneys' fees) arising from theft, loss, or damage related
#      to the Software.
#
# ================================================================================
#                  COPYRIGHT © 2024 BLENDERBIN LLC. ALL RIGHTS RESERVED.
# ================================================================================